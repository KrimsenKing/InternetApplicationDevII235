﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MovieLibrary;

namespace WebApplication1
{
    public partial class DLLConsumer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            MovieUtilities mu = new MovieUtilities();
            GridView1.DataSource = mu.SelectAll();
            GridView1.DataBind();
        }
    }
}